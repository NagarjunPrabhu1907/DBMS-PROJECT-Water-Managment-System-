<div class="footer">
          <p style="color: red">&copy; 2022 WSMS . All Rights Reserved </p>
        </div>